package com.jdbcconnectivity.InventoryManagementSystem.dao.impl;

public class SupplierDAOImpl {

}
