package com.jdbcconnectivity.InventoryManagementSystem.dao.impl;

import com.jdbcconnectivity.InventoryManagementSystem.dao.CategoryDAO;
import com.jdbcconnectivity.InventoryManagementSystem.model.Category;
import com.jdbcconnectivity.InventoryManagementSystem.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAOImpl implements CategoryDAO {

    public void add(Category c) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO category(category_name) VALUES (?)")) {
            ps.setString(1, c.getName());
            ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<Category> getAll() {
        List<Category> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM category")) {

            while (rs.next()) {
                Category c = new Category();
                c.setId(rs.getInt(1));
                c.setName(rs.getString(2));
                list.add(c);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
}
