package com.jdbcconnectivity.InventoryManagementSystem.dao;

import com.jdbcconnectivity.InventoryManagementSystem.model.Category;
import java.util.List;

public interface CategoryDAO {
    void add(Category c);
    List<Category> getAll();
}
