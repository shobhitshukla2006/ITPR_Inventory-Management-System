package com.jdbcconnectivity.InventoryManagementSystem.model;

public class Supplier {

}
