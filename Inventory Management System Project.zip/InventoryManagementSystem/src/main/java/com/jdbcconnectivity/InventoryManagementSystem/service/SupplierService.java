package com.jdbcconnectivity.InventoryManagementSystem.service;

public interface SupplierService {

}
