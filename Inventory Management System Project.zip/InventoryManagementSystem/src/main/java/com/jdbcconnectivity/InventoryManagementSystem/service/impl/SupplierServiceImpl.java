package com.jdbcconnectivity.InventoryManagementSystem.service.impl;

public class SupplierServiceImpl {

}
