package com.jdbcconnectivity.InventoryManagementSystem.dao;

public interface SupplierDAO {

}
