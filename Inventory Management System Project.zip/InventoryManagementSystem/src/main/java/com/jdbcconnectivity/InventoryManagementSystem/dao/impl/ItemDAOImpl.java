package com.jdbcconnectivity.InventoryManagementSystem.dao.impl;

import com.jdbcconnectivity.InventoryManagementSystem.dao.ItemDAO;
import com.jdbcconnectivity.InventoryManagementSystem.model.Item;
import com.jdbcconnectivity.InventoryManagementSystem.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDAOImpl implements ItemDAO {

    public void add(Item i) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO item(item_name,category_id,quantity,reorder_level) VALUES (?,?,?,?)")) {
            ps.setString(1, i.getName());
            ps.setInt(2, i.getCategoryId());
            ps.setInt(3, i.getQuantity());
            ps.setInt(4, i.getReorderLevel());
            ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<Item> getAll() {
        List<Item> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM item")) {

            while (rs.next()) {
                Item i = new Item();
                i.setId(rs.getInt(1));
                i.setName(rs.getString(2));
                i.setQuantity(rs.getInt(4));
                list.add(i);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public void updateQty(int id, int qty) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE item SET quantity = quantity + ? WHERE item_id=?")) {
            ps.setInt(1, qty);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<Item> lowStock() {
        List<Item> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT * FROM item WHERE quantity <= reorder_level")) {

            while (rs.next()) {
                Item i = new Item();
                i.setName(rs.getString(2));
                i.setQuantity(rs.getInt(4));
                list.add(i);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
}
