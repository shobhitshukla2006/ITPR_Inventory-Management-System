package com.jdbcconnectivity.InventoryManagementSystem;

import com.jdbcconnectivity.InventoryManagementSystem.model.*;
import com.jdbcconnectivity.InventoryManagementSystem.service.*;
import com.jdbcconnectivity.InventoryManagementSystem.service.impl.*;

import java.util.Scanner;

public class App {

    static Scanner sc = new Scanner(System.in);
    static CategoryService categoryService = new CategoryServiceImpl();
    static ItemService itemService = new ItemServiceImpl();

    public static void main(String[] args) {

        while (true) {
            System.out.println("\n1.Add Category");
            System.out.println("2.View Categories");
            System.out.println("3.Add Item");
            System.out.println("4.View Items");
            System.out.println("5.Update Stock");
            System.out.println("6.Low Stock");
            System.out.println("7.Exit");
            System.out.print("Choice: ");

            int ch = sc.nextInt();

            switch (ch) {

                case 1:
                    sc.nextLine();
                    Category c = new Category();
                    System.out.print("Category Name: ");
                    c.setName(sc.nextLine());
                    categoryService.add(c);
                    break;

                case 2:
                    for (Category cat : categoryService.getAll()) {
                        System.out.println(cat.getId()+" "+cat.getName());
                    }
                    break;

                case 3:
                    sc.nextLine();
                    Item i = new Item();
                    System.out.print("Item Name: ");
                    i.setName(sc.nextLine());
                    System.out.print("Category ID: ");
                    i.setCategoryId(sc.nextInt());
                    System.out.print("Quantity: ");
                    i.setQuantity(sc.nextInt());
                    System.out.print("Reorder Level: ");
                    i.setReorderLevel(sc.nextInt());
                    itemService.add(i);
                    break;

                case 4:
                    for (Item item : itemService.getAll()) {
                        System.out.println(item.getId()+" "+item.getName()+" "+item.getQuantity());
                    }
                    break;

                case 5:
                    System.out.print("Item ID: ");
                    int id = sc.nextInt();
                    System.out.print("Qty +/-: ");
                    int q = sc.nextInt();
                    itemService.updateQty(id, q);
                    break;

                case 6:
                    for (Item item : itemService.lowStock()) {
                        System.out.println("LOW STOCK: "+item.getName()+" "+item.getQuantity());
                    }
                    break;

                case 7:
                    System.exit(0);
            }
        }
    }
}
