package com.jdbcconnectivity.InventoryManagementSystem.dao;

import com.jdbcconnectivity.InventoryManagementSystem.model.Item;
import java.util.List;

public interface ItemDAO {
    void add(Item i);
    List<Item> getAll();
    void updateQty(int id, int qty);
    List<Item> lowStock();
}
