package com.jdbcconnectivity.InventoryManagementSystem.service.impl;

import com.jdbcconnectivity.InventoryManagementSystem.dao.CategoryDAO;
import com.jdbcconnectivity.InventoryManagementSystem.dao.impl.CategoryDAOImpl;
import com.jdbcconnectivity.InventoryManagementSystem.model.Category;
import com.jdbcconnectivity.InventoryManagementSystem.service.CategoryService;

import java.util.List;

public class CategoryServiceImpl implements CategoryService {

    private CategoryDAO dao = new CategoryDAOImpl();

    public void add(Category c) {
        dao.add(c);
    }

    public List<Category> getAll() {
        return dao.getAll();
    }
}
