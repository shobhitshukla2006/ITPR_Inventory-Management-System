package com.jdbcconnectivity.InventoryManagementSystem.service;

import com.jdbcconnectivity.InventoryManagementSystem.model.Category;
import java.util.List;

public interface CategoryService {
    void add(Category c);
    List<Category> getAll();
}
