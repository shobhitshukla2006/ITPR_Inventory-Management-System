package com.jdbcconnectivity.InventoryManagementSystem.service;

import com.jdbcconnectivity.InventoryManagementSystem.model.Item;
import java.util.List;

public interface ItemService {
    void add(Item i);
    List<Item> getAll();
    void updateQty(int id, int qty);
    List<Item> lowStock();
}
