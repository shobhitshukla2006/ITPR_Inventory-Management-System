package com.jdbcconnectivity.InventoryManagementSystem.service.impl;

import com.jdbcconnectivity.InventoryManagementSystem.dao.ItemDAO;
import com.jdbcconnectivity.InventoryManagementSystem.dao.impl.ItemDAOImpl;
import com.jdbcconnectivity.InventoryManagementSystem.model.Item;
import com.jdbcconnectivity.InventoryManagementSystem.service.ItemService;

import java.util.List;

public class ItemServiceImpl implements ItemService {

    private ItemDAO dao = new ItemDAOImpl();

    public void add(Item i) {
        dao.add(i);
    }

    public List<Item> getAll() {
        return dao.getAll();
    }

    public void updateQty(int id, int qty) {
        dao.updateQty(id, qty);
    }

    public List<Item> lowStock() {
        return dao.lowStock();
    }
}
